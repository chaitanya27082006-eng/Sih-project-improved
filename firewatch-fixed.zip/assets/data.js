// FireWatch page data. REAL detection feed - generated from our actual pipeline.
// Columns: lat, lon, type, confidence, risk, source, region, distance_km (to nearest mapped industrial site), days_seen
window.FW_DATA = {
  sites: [
    [21.1658, 72.6623, "Industrial Fire", 55, "Medium", "NASA FIRMS (VIIRS), live", "Surat-Bharuch-Vadodara corridor, Gujarat, India", 0.0, 1],
    [22.3826, 73.1285, "Industrial Fire", 55, "Medium", "NASA FIRMS (VIIRS), live", "Surat-Bharuch-Vadodara corridor, Gujarat, India", 0.8, 1],
    [20.3535, 72.9503, "Agricultural Burning", 70, "Medium", "NASA FIRMS (VIIRS), live", "Surat-Bharuch-Vadodara corridor, Gujarat, India", 2.0, 1],
    [20.3569, 72.9483, "Industrial Fire", 55, "Medium", "NASA FIRMS (VIIRS), live", "Surat-Bharuch-Vadodara corridor, Gujarat, India", 1.7, 1],
    [21.1031, 72.6457, "Industrial Fire", 55, "Medium", "NASA FIRMS (VIIRS), live", "Surat-Bharuch-Vadodara corridor, Gujarat, India", 0.8, 1],
    [21.1644, 72.673, "Industrial Fire", 55, "Medium", "NASA FIRMS (VIIRS), live", "Surat-Bharuch-Vadodara corridor, Gujarat, India", 0.5, 2],
    [21.1671, 72.6728, "Industrial Fire", 55, "Medium", "NASA FIRMS (VIIRS), live", "Surat-Bharuch-Vadodara corridor, Gujarat, India", 0.2, 1],
    [21.1014, 72.6347, "Industrial Fire", 55, "Medium", "NASA FIRMS (VIIRS), live", "Surat-Bharuch-Vadodara corridor, Gujarat, India", 1.3, 2],
    [21.104, 72.6364, "Industrial Fire", 75, "High", "NASA FIRMS (VIIRS), live", "Surat-Bharuch-Vadodara corridor, Gujarat, India", 1.0, 4],
    [21.1074, 72.637, "Industrial Fire", 75, "High", "NASA FIRMS (VIIRS), live", "Surat-Bharuch-Vadodara corridor, Gujarat, India", 0.8, 3],
    [21.4322, 72.9772, "Industrial Fire", 55, "Medium", "NASA FIRMS (VIIRS), live", "Surat-Bharuch-Vadodara corridor, Gujarat, India", 1.8, 1],
    [21.1067, 72.6454, "Industrial Fire", 90, "Critical", "NASA FIRMS (VIIRS), live", "Surat-Bharuch-Vadodara corridor, Gujarat, India", 0.4, 5]
  ]
};